# Moderationide
Moderationide V2:
A Bot for Boronide.

## Requires:
**Py-cord 2.1.1 or higher**

`pip install -U py-cord==2.1.1`

**Python 3.10 is recommended**

## About Moderationide
Moderationide is a discord bot for boronide.
ModerationideV2 is a rewrite by MathcelF (me)
-> Under main/cogs/commands/ you will find run.py
It was provided by X3: I rewrote it. 

Moderationide will be always open source.
It is a part of boronide so support can be received in Boronide Ticket System.
Or (will mention it often) my email: mathcelf@tutanota.com

It would be nice to leave some credits for me:)
It took a bit of time, but it is done now.

## Changes?
In comparison to Moderationide V1:
Data is stored on MongoDB, instead on the host... (Don't ask me, why it was like that)
Different Permission System, instead of having them on the local file:
User Data is stored on the DB (not sensitive information) such as Flags:
Flags will be calculated and if the user has certain flags, he can use the commands.

Remade the Verification System.
Shame on Herrtt, he did not implement the backend somehow.
Or shame on the other website devs.


The project is a bit inconsistent in the style, so if you got suggestions/tips.
I am open to them.

Rewrote a lot, made stuff more efficient, and 'OOP' even tho sometimes I mess up with some things.


# Start & Host
To run the Bot you need python 3.10 and use the command
python3 bot.py

To host the bot permanently, you need a VPS.
Contabo, Hetzner are some vialable options.
Or any other.

Report the bugs / Issues anywhere.
If it's important, please open a Ticket in Boronide
-> I will be contacted.

The bot is using the py-cord library.

# Facit:

If you need help / got questions, contact MathcelF or the  Boronide Support Team.
Regards or anything: pleases to my email: mathcelf@tutanota.com
