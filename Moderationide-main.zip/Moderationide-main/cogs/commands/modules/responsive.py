from p_modules import get
from p_modules.database.main import Database
from p_modules.utilities.flag import Flag
from p_modules.graphical.embeds import Embed
import json

languages = ['Русский', 'Deutsch', 'English']
video_list = [
    'https://www.youtube.com/watch?v=4-IIr6qubOI',
    'https://www.youtube.com/watch?v=RylDtyNPa0A',
    'https://www.youtube.com/watch?v=TwE5E2fIiSM'
]
