const luamin = require('./luamin')

exports.Beautify = luamin.Beautify
exports.Minify = luamin.Minify
exports.Uglify = luamin.Uglify